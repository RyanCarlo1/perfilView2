package br.sc.senac.perfil.view;

import br.sc.senac.perfil.util.ConnectionFactory;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

public class LoginView extends JFrame {
    private JPanel pnlPerfil;
    private JLabel lblnome;
    private JLabel lblcurso;
    private JLabel lblfase;
    private JLabel lblnascimento;

    private JTextField txtnome;
    private JTextField txtnascimento;
    private JTextField txtcurso;
    private JButton btnenviar;
    private JTextField txtfase;

    public LoginView() {
        initComponents();
        addListeners();
    }

    private void initComponents() {
        setTitle("Perfil de Usuário");
        setSize(300, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setContentPane(pnlPerfil);
        setVisible(true);
        pnlPerfil.setLayout(null);
    }

    private void addListeners() {
        btnenviar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                txtnome.setText("");
                txtcurso.setText("");
                txtnascimento.setText("");
                txtfase.setText("");

                Connection conn = ConnectionFactory.getConexao();
            }
        });
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new LoginView();
            }
        });

    }
}
